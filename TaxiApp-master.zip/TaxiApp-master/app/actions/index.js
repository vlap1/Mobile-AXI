import * as registrationActions from './registration'

export const ActionCreators = Object.assign({},
    registrationActions,
);
