import React, { Component } from 'react';
import {
    Dimensions,
} from 'react-native';
const dim = Dimensions.get('window');