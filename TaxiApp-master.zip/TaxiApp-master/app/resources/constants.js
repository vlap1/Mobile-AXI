/**
 * Created by innopolis2 on 02.04.17.
 */

module.exports = {
    stream: 'http://streamplenty.streaming.mediaservices.windows.net/a36bfc1b-5d04-4303-81d8-47250b103554/b2e78d0aec874bcdb05cb319e0e54d1b.ism/QualityLevels(415269)/Manifest(video,format=m3u8-aapl)',
    welcome_board_button_text: 'Sign Up or Log In',
    confirmation: 'Confirmation',
    phoneinputheadertitle: 'Please insert your cell phone number',
    phoneinputheadercontent: 'It will be used only for identification'
};
