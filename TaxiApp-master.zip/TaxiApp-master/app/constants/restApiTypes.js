/**
 * Created by innopolis on 28.10.16.
 */
"use strict";
import React, {Component} from 'react';

export class Constants extends Component {
    //Api
    static HTTP = 'http://';
    static HTTPS = 'https://';
    static DOMEN = '';
  
}