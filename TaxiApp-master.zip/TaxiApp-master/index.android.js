'use strict';
import React, {
  AppRegistry
} from 'react-native';

import App from './app/containers/app.js';

AppRegistry.registerComponent('TaxiApp', () => App);